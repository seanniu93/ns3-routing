#! /usr/bin/env python

"""Generic trace-comparison-type regression test."""

